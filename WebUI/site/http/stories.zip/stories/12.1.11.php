<div class="panel">
	<div class="panel-wrapper">
		<h2 class="title">World Premiere</h2>
		<p>The World Premiere of VirPong will be hosted at the University of Puget Sound on Wednesday, December 14, 2011 at 4 pm. 
		    For directions please use <a href = "http://maps.google.com/maps?q=University+of+Puget+Sound,+North+Warner+Street,+Tacoma,+WA&hl=en&sll=37.0625,-95.677068&sspn=40.052282,86.572266&vpsrc=0&hq=University+of+Puget+Sound,+North+Warner+Street,+Tacoma,+WA&t=h&z=15" target="_blank">Google Maps</a>.</p>
		
		<p><span class = "newsauthor"> Posted By: Sally Sue </span> <br />
		<span class = "newsdate"> December 1, 2011 </span></p>
	</div>
</div>