<div class="panel">
	<div class="panel-wrapper">
		<h2 class="title">Private Viewing</h2>
		<p>VirPong was released for a private viewing on the campus of the University of Puget Sound. The game received many 
		    positive reviews. A public viewing of the game will be announced shortly.</p>
			
		<p><span class = "newsauthor"> Posted By: Sally Sue </span> <br />
		<span class = "newsdate"> September 5, 2011 </span></p>
	</div>
</div>